package com.myshopping;

public class SingletonTest {
	public static void main(String[] args) {
		System.out.println("Begin");
		 
		
		Kitchen k1 = Kitchen.getKitchen();
		Kitchen k2 = Kitchen.getKitchen();
		Kitchen k3 = Kitchen.getKitchen();
		
		System.out.println("k1 "+k1);
		System.out.println("k2 "+k2);
		System.out.println("k3 "+k3);
		
		System.out.println("End");
	}
}
class Kitchen // below code is of SINGLETON DESIGN PATTERN
{
	static Kitchen k = null; //created only once
	
	private Kitchen() { //private to the outside world
		System.out.println("Kitchen() constructor....");
	}
	static Kitchen getKitchen() { //can access ctr fro here
		if(k == null)
			k = new Kitchen(); 
		
		return k; //return this k
	}
}
