package com.myshopping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.myshopping.pojo.Department;
 
public class ModifyObjectTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		SessionFactory sessionFactory =
			    new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		//
		System.out.println("sessionFactory : "+sessionFactory);
		
		Session session = sessionFactory.getCurrentSession();
		System.out.println("session        : "+session);
		
		session.getTransaction().begin();
	
			Department deptObj = new Department(); // blank object
			
			//u know 98 as a PK exists in the table, then will fire update
			//if the PK not found then it will fire insert query
			deptObj.setDepartmentNumber(98); 
			deptObj.setDepartmentName("EXAM");
			deptObj.setDepartmentLocation("TODAY");
			
			session.saveOrUpdate(deptObj); //this will fire update query
			
			/*System.out.println("DEPTNO : "+deptObj.getDepartmentNumber());
			System.out.println("DNAME  : "+deptObj.getDepartmentName());
			System.out.println("LOC    : "+deptObj.getDepartmentLocation());*/
			
			
		System.out.println("Commiting...");
		session.getTransaction().commit();
		
		System.out.println("Committed...");
		
	}

}
