package com.myshopping;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.myshopping.pojo.Department;
import com.myshopping.pojo.Employee;
 
public class SelectEmpTest {

	public static void main(String[] args) {
		SessionFactory sessionFactory =
			    new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		System.out.println("sessionFactory : "+sessionFactory);
		
		Session session = sessionFactory.getCurrentSession();
		System.out.println("session        : "+session);
		
		session.getTransaction().begin();
	
			List<Employee> allEmps = new ArrayList<Employee>(); 
			
			Query query = session.createQuery("from Employee");
			allEmps = query.list();
			
			Iterator<Employee> empIter = allEmps.iterator();
			
			while(empIter.hasNext()) {
				Employee theEmp = empIter.next();
				System.out.println("EMPNO      : "+theEmp.getEmployeeNumber());
				System.out.println("ENAME      : "+theEmp.getEmployeeName());
				System.out.println("JOB        : "+theEmp.getEmployeeJob());	
				System.out.println("MGR        : "+theEmp.getEmployeeManager());
				System.out.println("HIREDATE   : "+theEmp.getEmployeeHiredate());
				System.out.println("SALARY     : "+theEmp.getEmployeeSalary());
				System.out.println("COMM       : "+theEmp.getEmployeeCommission());
				System.out.println("--------------------");
			}
			
			
		System.out.println("Commiting...");
		session.getTransaction().commit();
		
		System.out.println("Committed...");
		
	}

}
