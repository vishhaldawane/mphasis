package com.myshopping;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.myshopping.dao.DepartmentDAOImpl;
import com.myshopping.pojo.Department;
import com.myshopping.pojo.Employee;
 
public class SelectObjectTest3 {

	public static void main(String[] args) {
		
			DepartmentDAOImpl ddi = new DepartmentDAOImpl();
			
			List<Department> deptList = ddi.findDepartments();

			for (Department deptObj : deptList) { //the forEach loop for list
				System.out.println("---DEPARTMNENT----");
				System.out.println("DEPTNO : "+deptObj.getDepartmentNumber());
				System.out.println("DNAME  : "+deptObj.getDepartmentName());
				System.out.println("LOC    : "+deptObj.getDepartmentLocation());
				
				List<Employee> myEmps = deptObj.getEmpList();
				Iterator<Employee> empIter = myEmps.iterator();
				System.out.println("---EMPLOYEES FROM ----"+deptObj.getDepartmentName()+" Branch");
				while(empIter.hasNext()) {
					Employee theEmp = empIter.next();
					System.out.println("EMPNO      : "+theEmp.getEmployeeNumber());
					System.out.println("ENAME      : "+theEmp.getEmployeeName());
					System.out.println("JOB        : "+theEmp.getEmployeeJob());	
					System.out.println("MGR        : "+theEmp.getEmployeeManager());
					System.out.println("HIREDATE   : "+theEmp.getEmployeeHiredate());
					System.out.println("SALARY     : "+theEmp.getEmployeeSalary());
					System.out.println("COMM       : "+theEmp.getEmployeeCommission());
					System.out.println("--------------------");
				}
			}
	}

}
