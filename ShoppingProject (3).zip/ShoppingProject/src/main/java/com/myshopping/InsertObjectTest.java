package com.myshopping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.myshopping.pojo.Department;
 
public class InsertObjectTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		SessionFactory sessionFactory =
			    new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		//
		System.out.println("sessionFactory : "+sessionFactory);
		
		Session session = sessionFactory.getCurrentSession();
		System.out.println("session        : "+session);
		
		session.getTransaction().begin();
	
			Department deptObj = new Department();
			deptObj.setDepartmentNumber(98);
			deptObj.setDepartmentName("Coding");
			deptObj.setDepartmentLocation("Pune");
			//deptObj.set
			
			session.save(deptObj); //will fire the insert query
			
		System.out.println("Commiting...");
		session.getTransaction().commit();
		
		System.out.println("Committed...");
		
	}

}
