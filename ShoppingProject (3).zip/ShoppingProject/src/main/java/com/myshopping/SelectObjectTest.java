package com.myshopping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.myshopping.pojo.Department;
 
public class SelectObjectTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		SessionFactory sessionFactory =
			    new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		//
		System.out.println("sessionFactory : "+sessionFactory);
		
		Session session = sessionFactory.getCurrentSession();
		System.out.println("session        : "+session);
		
		session.getTransaction().begin();
	
			Department deptObj = null; // no object here
			
					//below function would run a select query
					//to fetch a single record for the primary key
			deptObj = session.get(Department.class,98); //98 is deptno
			
			System.out.println("DEPTNO : "+deptObj.getDepartmentNumber());
			System.out.println("DNAME  : "+deptObj.getDepartmentName());
			System.out.println("LOC    : "+deptObj.getDepartmentLocation());
			
		System.out.println("Commiting...");
		session.getTransaction().commit();
		
		System.out.println("Committed...");
		
	}

}
