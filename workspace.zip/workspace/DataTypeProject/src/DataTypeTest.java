
public class DataTypeTest {
	public static void main(String[] args) {
		byte nurseryROllNumber=13;
		short collegeRollNumber=1904;
		int universityNumber=34980;
		long harvadUniversityNumber = 68934;
		
		float rateOfInterest = 3.689f; //f means its a float and not double
		double molecularDistance = 0.0045; // it is by default double

		char myGender = 'F';
		
		boolean falseDoesNotNeedProof = false;
		System.out.println("My Nursery Roll Number : "+nurseryROllNumber);
		System.out.println("My College Roll Number : "+collegeRollNumber);
		System.out.println("My Unive   Roll Number : "+universityNumber);
		System.out.println("My Harvard Roll Number : "+harvadUniversityNumber);
		
		System.out.println("My Gender is           : "+myGender);
		
		System.out.println("My home loan rate is   : "+rateOfInterest);
		System.out.println("Molecular distance is  : "+molecularDistance);
		
		System.out.println("False doesnt need proof: "+falseDoesNotNeedProof);
		
		
		
	}

}
