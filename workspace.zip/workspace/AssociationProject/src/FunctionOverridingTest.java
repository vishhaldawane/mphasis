public class FunctionOverridingTest {
	public static void main(String[] args) {
		/*
		Doctor d = new Doctor();		d.diagnose(); //compile-time binding
		System.out.println("-----------");
		
		Surgeon s = new Surgeon();		s.diagnose();		s.doSurgery(); //compile-time binding
		System.out.println("-----------");
		
		HeartSurgeon hs = new HeartSurgeon();		hs.diagnose();
		hs.doSurgery();		hs.doHeartSurgery(); //compile-time binding
		*/
		Doctor d = new Doctor();
		d.diagnose(); //during compile time it is binding method of Doctor
		
		d = new Surgeon();
		d.diagnose(); //during compile time it is binding method of Doctor
		//but at runtime it will fetch the method of Surgeon (where it is pointing)
		
		d = new HeartSurgeon();
		d.diagnose(); //during compile time it is binding method of Doctor
		//but at runtime it will fetch the method of HeartSurgeon (where it is pointing)
	}
}
class Doctor {
	void diagnose() { System.out.println("Doctor is diagnosing...ENT checkup");	}
}
class Surgeon extends Doctor {
	void diagnose() { //this is the re-definition of the Doctor's diagnose
		System.out.println("Surgeon is diagnosing...ENT + some test...");
	}
	void doSurgery() { 	System.out.println("Surgeon is doing surgery...");	}
}
class HeartSurgeon extends Surgeon {
	void diagnose() { //this is the re-definition of the Doctor's diagnose
		System.out.println("HeartSurgeon is diagnosing...ENT + some test...+ECG test");
	}
	void doSurgery() { // refinement of its super class method - overriding 
		System.out.println("HeaertSurgeon is doing surgery...");
	}
	void doHeartSurgery() {	System.out.println("HeaertSurgeon is doing Heart surgery...");
	}
}