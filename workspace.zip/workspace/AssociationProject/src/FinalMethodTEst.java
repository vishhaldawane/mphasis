
public class FinalMethodTEst {
	public static void main(String[] args) {
		Chess c = new Chess();
		c.moveBishop();
		
		GraphicalChess  gc = new GraphicalChess();
		gc.moveMyBishop();
	}
}

final class Chess //means this is the final version of the class
{ 
	//below is the final version | cannot be overridden
	final void moveBishop() { //overriding is prevented due to final
		System.out.println("Bishop is moving diagonal...X pattern");
	}
}
class GraphicalChess// extends Chess //cannot be extended due to final
{
	void moveMyBishop() { //its not overriding, since new name
		System.out.println("Bishop is moving L Shape...");
	}
}
