public class FinalTest {
	public static void main(String[] args) {
		final float PI=3.14f; //local field of main
		System.out.println("PI "+PI);
		Circle c = new Circle(23);
		c.showCircle();		c.calcArea();
	}
}
class Circle {
	int radius;	final float PI=3.14f; //final field of the Circle class
	Circle(int r) {		radius = r; 	}
	void showCircle() {
		System.out.println("Circle radius "+radius);
	}
	void calcArea() { float area = PI * radius * radius;
		System.out.println("Area is "+area);
	}
}