
public class SomeExceptioneTest {
	public static void main(String[] args) {
		
		System.out.println("Begin");
		int score[]= {10,20,30};
		System.out.println("value "+score[22]);
		System.out.println("End");
		String msg=null;
		System.out.println("letter : "+msg.charAt(9));
		
	}
}
