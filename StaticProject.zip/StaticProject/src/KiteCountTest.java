public class KiteCountTest {
	public static void main(String[] args) {
		System.out.println("Begin main");
		Kite.showKiteCount();
		Kite k1 = new Kite("Ashish","Blank",70);
		Kite k2 = new Kite("Pawan","Yellow",50);
		Kite k3 = new Kite("Sriram","Orange",60);
		Kite.showKiteCount();
	}
}
class Kite {
	private String color; private String owner; private int length; //data member of the object
	//below is not the data member of the object | its a class's member
	private static int kiteCount; // independent of Kite objects
	static void showKiteCount() { //static can always refer static
		System.out.println("Kite Count : "+Kite.kiteCount);
		//color="red"; //static cannot refer to non-static
	}
	//whether kite is there or not in the sky //this variable would be present
	Kite(String color, String owner, int length) {
		super(); System.out.println("Kite is constructed.....");
		this.color = color;	this.owner = owner;		this.length = length;
		++kiteCount; // increase the value by one
			
	}
	void showKite() { //non-"static" function can refer static
		System.out.println("Kite Owner  : "+owner);
		System.out.println("Kite color  : "+color);
		System.out.println("Kite length : "+length);
		System.out.println("Kite Count  : "+kiteCount); //valid
	}
	
}














