public class CarTest {
	public static void main(String[] args) {
		
		//it isA Vehicle
		Car myCar = new Car(); //it "has an" Engine
		
		ExpressWay xprsWay = new ExpressWay();

		//producesA Travel
		Travel myTrv = myCar.drive(xprsWay); //uses ExpressWay
		myTrv.fun();
	}
}
class Vehicle
{
	void move() { //inherited to its children
		System.out.println("Vehile is moving...");
	}
}
class Car extends Vehicle //isA
{
	//below line is a data member of the Car
	Engine eng = new Engine(); //hasA
	
	Travel drive(ExpressWay exWay) {
		eng.ignite();
		System.out.println("Car is using "+exWay.laneCount+" lane way");
		System.out.println("Driving the Car....");
		Travel tvl = new Travel();
		return tvl;
	}
}

class Engine
{
	void ignite() {
		System.out.println("Igniting the Engine...");
	}
}

class Road
{
	int laneCount=2;
}

class HighWay extends Road
{
	int laneCount=4;
	
}

class ExpressWay extends HighWay
{
	int laneCount=8;
	
}

class Travel
{
	void fun() {
		System.out.println("Travel is a fun...");
	}
}