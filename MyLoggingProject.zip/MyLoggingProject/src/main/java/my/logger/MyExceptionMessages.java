package my.logger;
import org.apache.log4j.Logger;


public class MyExceptionMessages {
	 final static Logger logger = Logger.getLogger(MyExceptionMessages.class);
	    
	    public static void main(String[] args) {
	    
	    	MyExceptionMessages obj = new MyExceptionMessages();
	        
	        try{
	            obj.divide();
	        }catch(ArithmeticException ex){
	            logger.error("Sorry, something wrong!", ex);
	        }
	        
	        
	    }
	    
	    private void divide(){
	        
	        int i = 10 /0;

	    }
}
