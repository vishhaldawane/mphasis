package jungle.river;

class Crocodile {
	void swim() {
		System.out.println("Crocodile is swimming...");
	}
}
