package jungle.safari;
import jungle.cave.Tiger;
public class Visitor {

	public static void main(String[] args) {
	//lets learn in mute mode
	Tiger t = new Tiger();	

	}

}
