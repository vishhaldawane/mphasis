package jungle.tree;

import jungle.cave.Tiger;

class Monkey {
	void swing() {
		System.out.println("Monkey is swinging...");
	}
}
class DragonFly { //is not a child of the Tiger, but inside the cave
	void observingFromTree(Tiger t) { //usesA relationship
		System.out.println("My Age is "+t.privateAge); //this one is understood
		System.out.println("My Age is "+t.protectedAge);//ohHH look at this
		System.out.println("My Age is "+t.publicAge);
		System.out.println("My Age is "+t.defaultAge);
	}
}
class WildTiger extends Tiger //isA 
{
	void hunt() {
		System.out.println("My Age is "+privateAge); //this one is understood
		System.out.println("My Age is "+protectedAge);//ohHH look at this
		System.out.println("My Age is "+publicAge);
		System.out.println("My Age is "+defaultAge);
	}
}
