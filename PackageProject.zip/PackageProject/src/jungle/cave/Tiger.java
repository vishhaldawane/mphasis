package jungle.cave;

 public class Tiger {
	 private   int privateAge; //2nd one
     protected int protectedAge; //2nd one
	 public int publicAge; // 3rd one
	       int defaultAge; //4th one
	       
	void jump() {
		System.out.println("Tiger is jumping...");
	}
} //lets mute and learn for some time | beyond my control 
//TYPE THIS CODE AND EXPERIENCE THE SAME 
class ButterFly { //is not a child of the Tiger, but inside the cave
	void flyingAroundTheNoseOf(Tiger t) { //usesA relationship
		System.out.println("My Age is "+t.privateAge); //this one is understood
		System.out.println("My Age is "+t.protectedAge);//ohHH look at this
		System.out.println("My Age is "+t.publicAge);
		System.out.println("My Age is "+t.defaultAge);
	}
}
class WhiteTiger extends Tiger {
	void jumpingInTheSnow() {
		System.out.println("My Age is "+privateAge);
		System.out.println("My Age is "+protectedAge);
		System.out.println("My Age is "+publicAge);
		System.out.println("My Age is "+defaultAge);
	}
}