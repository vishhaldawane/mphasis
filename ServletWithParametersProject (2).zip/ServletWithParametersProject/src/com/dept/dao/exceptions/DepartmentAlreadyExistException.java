package com.dept.dao.exceptions;

//u already know how to make checked exception
//com.dept.dao.exception - STEP 1
public class DepartmentAlreadyExistException extends Exception {
	public DepartmentAlreadyExistException(String msg) { super(msg); } }
